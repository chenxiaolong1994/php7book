<?php
$uid = $_REQUEST['uid'];
if($data = $user->findByUid($uid) != false) {
	$this->output($data);
} else {
	$this->output('',1,'invalid uid');
}

function output(,$data='',$code=0,$msg='success') {
	$out = array('code'=$code,'msg'=>$msg,'data'=>$data);
	echo json_encode($out);
}

echo json_encode(array('code'=>0,'msg'=>'success','data'=>array('name'=>'chenxiaolong','age'=>'22','gender'=>'male')));

?>
