<?php
// error_reporting(0);
// function theDatabaseObj(){
//     $mysql = mysqli_connect('127.0.0.1','chenxiaolong','8731787','3306');
//      if( $mysql ){
//          return $mysql; 
//      } else {
//          throw new Exception("Could not connect to the database");
//      }
// }

// function db(){
//      try{
//          $db = theDatabaseObj();
//          var_dump($db);
//      }
//      catch( Exception $e ){
//         echo $e->getMessage();
         
//      }
// }

// db();


// class emailException extends Exception{
//     function __toString(){
//         return "<h1>email is null</h1>file:".$this->getFile().',line:'.$this->getLine();
        
//     }
// }

// class nameException extends Exception{

// }

// function reg($reg) {
//     if (empty($reg['email'])) {
//         throw new emailException("emaill is null", 1);
        
//     }
//     if(empty($reg['name'])) {
//         throw new nameException("name is null", 2);
        
//     }
// }

// try{
//     $reg = array('phone'=>'1888888888');
//     reg($reg);
// } catch(emailException $e) {
//     echo $e;

// } catch(nameException $e) {
//     echo 'error msg:' .$e->getMessage().'error code:'.$e->getCode();
// } finally {
//     echo 'finally';
// }

// $a = new aaa();

// try{
//     $a = new aa();
// } catch(Error $e) {
//     var_dump($e);
// 

// function exception_handler($exception) {
//   echo "Uncaught exception: " , $exception->getMessage(), "\n";
// }

// set_exception_handler('exception_handler');

// throw new Exception('Uncaught Exception');
// echo "Not Executed\n";

try{
    $a = new cat();
}catch(Error $e) {
    echo 'error msg:'.$e->getMessage().' error line:'.$e->getLine();
}


// function error_handler($errno, $errstr, $errfile, $errline ) {
//     echo "error number:".$errno."<br/>";
//     echo "error msg:".$errstr."<br/>";
//     echo "error file:".$errfile."<br/>";
//     echo "error line:".$errline."<br/>";
//     die('something error');
//     // throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
// }
// set_error_handler("error_handler");
// /* Trigger exception */
// try {
//     $a = 5/0;
//     var_dump($a);
// } catch(Exception $e) {
//     echo $e->getMessage();
// }



?>