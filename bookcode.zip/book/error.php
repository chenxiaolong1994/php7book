<?php
function exception_error_handler($errno, $errstr, $errfile, $errline ) {
    throw new ErrorException($errstr);
}
set_error_handler("exception_error_handler");

/* Trigger exception */
strpos();
?>