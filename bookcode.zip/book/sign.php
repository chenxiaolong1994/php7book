<?php

//echo $timestamp = time();
$timestamp = 1479651758;
//$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
//echo $randstr = substr(str_shuffle($str), 0,5);
$sign = "efd0330d616ce0e720ff591349339ea36a7e8110";
$url = "http://www.xxx.com?timestamp=$timestamp&randstr=$str&uid=1111&name=chenxiaolong&sign=$sign";
echo $url;echo "<br/>";
$arr=array(
'uid'=>$_GET['uid'],
'name'=>$_GET['name'],
'randstr'=>$_GET['randstr'],
'timestamp'=>$_GET['timestamp']);


$arr=array(
'uid'=>1111,
'name'=>'chenxiaolong',
'randstr'=>'ABCD',
'timestamp'=>1479651758);

 sort($arr); //字典排序的作用就是防止因为参数顺序不一致而导致下面拼接加密不同
 //print_r($arr);
 // 2. 将Key和Value拼接
 foreach ($arr as $k => $v) {
 		$str .= $v;
	 }
	 echo $str;echo "<br/>";

	echo $sign = sha1($str);



function check($arr,$sig) {
	sort($arr);
	$str = "";
	foreach ($arr as $k => $v) {
 		$str = $str.$arr[$k].$array[$v];
	 }

	$sign = sha1($str);
	if ($sign == $sig) {
		return true;
	} else {
		return false;
	}


}

?>