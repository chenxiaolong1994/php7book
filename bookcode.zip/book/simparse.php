<?php
$xmlstr = <<<XML
<?xml version='1.0' standalone='yes'?>
<movies attr='qwe' hah='fasdf'>
 <movie a='aa'>
  <title tt='ttt'>PHP: Behind the Parser</title>
  <characters>
   <character>
    <name age='22 years old' country='china'>Ms. Coder</name>
    <actor>Onlivia Actora</actor>
   </character>
   <character>
    <name>Mr. Coder</name>
    <actor>El Act&#211;r</actor>
   </character>
  </characters>
  <plot>
   So, this language. It's like, a programming language. Or is it a
   scripting language? All is revealed in this thrilling horror spoof
   of a documentary.
  </plot>
  <great-lines>
   <line>PHP solves all my web problems</line>
  </great-lines>
  <rating type="thumbs">7</rating>
  <rating type="stars">5</rating>
 </movie>
</movies>
XML;
$sx = simplexml_load_string($xmlstr);

echo $sx->movie->title;
echo ":";
//var_dump($sx->movie->characters);
echo $sx->movie->characters->character[0]->name.":";
 //获取属性值
echo $sx->movie->rating[1]['type'];

$sx->movie->characters->character[0]->name = 'Miss Coder';

echo $sx->asXML();

?>

