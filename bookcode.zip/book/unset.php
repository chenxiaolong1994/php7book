<?php
$image = imagecreatetruecolor(200, 300);
$a = imagecolorallocate($image, 2, 222, 111);


var_dump($a);
// 不要忘记输出正确的 header！
header('Content-type: image/png');

// 最后输出结果
imagepng($image);
imagedestroy($image);
?>
