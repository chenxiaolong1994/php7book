<?php

function add($n){
	if($n > 1) {
		$val = add($n-1) + add($n-2);
		return $val;
	} else {
		return 1;
	}
}
echo add(-3);
?>