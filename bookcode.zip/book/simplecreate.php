<?php
include 'xmlstr.php';
$movies = new SimpleXMLElement($xmlstr);
$string = <<<XML
<?xml version='1.0' encoding='utf-8'?> 
<dom></dom>
XML;
//载入xml字符串将其转换成对象
$book = simplexml_load_string($string);;
//创建元素并设置对应文本内容
$book->addChild('bookname','微信公众平台开发实战与应用案例');
$author = $book->addChild('author','陈小龙');
//设置元素的属性和值
$author->addAttribute('age','22 years old');
$book->addChild('press','清华大学出版社');
$book->addChild('publishtime','2016-07');
echo $book->asXML();



$character = $movies->movie[0]->characters->addChild('character');
$name = $character->addChild('name', 'Mr. Parser');
$name->addAttribute('age','22 years old');
$character->addChild('actor', 'John Doe');

$rating = $movies->movie[0]->addChild('rating', 'PG');
$rating->addAttribute('type', 'mpaa');

//echo $movies->asXML();

?>