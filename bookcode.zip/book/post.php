<?php
class conn{
	public $dbtype = 'mysql';
	const HOST = '127.0.0.1';
	private $username = 'root';
	private $password = '123456';
	private $pre = 'zwt_';
	public function test(){
		echo "test";
		//echo $this->getDbtype();  静态方法不能在类内部以$this->的形式访问
	}
	public function test1(){
		echo self::HOST;   // self访问常量
		self::getDbtype();  // self访问静态方法
	}
	public static function getDbtype(){ //使用static修饰的方法称为静态方法
		echo "mysql";
	}
	public function insert(){}
	public function update(){}
	public function delete(){}
	public function select(){}
}

class myclass{
	static $staticVal = 0;
	public $val = 100;
	static function getStaticVal(){
		echo self::$staticVal;
	}
	static function changeStaticVal(){
		self::$staticVal++;
		echo self::$staticVal;
		//$this->val++;
	}
	function change(){
		$this->changeStaticVal(); // 在类内部使用$this调用静态方法
	}
}

class yourclass{
	public $name;
	private $age;
	protected $weight;
	// function __construct($name,$age,$weight){
	// 	$this->name = $name;
	// 	$this->age = $age;
	// 	$this->weight = $weight;
	// }
	function like(){
		echo "I like money. ";
	}
	function age(){
		echo $this->name . ' is ' . $this->age . 'years old';
	}
	protected function get($key){
		return $this->$key;
	}
	

}
class hisclass extends yourclass{
	function set($key,$value){
		$this->$key = $value;
	}
	function get($key){   //重写父类方法
		echo $this->key;
	}
	function what(){
		parent::like();  //子类中访问父类方法
	}
	function getAge(){
		$this->age();   //调用从父类继承来的方法
	}
}


class animal{
	function can(){
		echo "this function weill be re-write in the children";
	}
}
class cat extends animal{
	function can(){
		echo "I can climb ";
	}
}

class dog extends animal{
	function can(){
		echo "I can swim";
	}
}

function test($obj){
	$obj->can();
}
// test(new cat());
// test(new dog());

class magic{
	public $father = 'chenxiaolong';
	private $_name;
	//private $_wight = '55kg';
	private $_age = '22 years old ';
	protected $__height = '170cm ';
	private $_hobby = 'basketball';
	function __set($key,$value){
		echo 'execute __set method ';
		$this->$key = $value;
	}
	// function __get($key){
	// 	echo 'execute __get() method ';
	// 	//var_dump($key);
	// 	$oldKey = $key;
	// 	if(isset($this->$key)){
	// 		return $this->$key;
	// 	}
	// 	$key = '_' . $key;
	// 	if(isset($this->$key)){
	// 		return $this->$key;
	// 	}
	// 	$key = '_' . $key;
	// 	if(isset($this->$key)){
	// 		return $this->$key;
	// 	}
	// 	return '$this->' . $oldKey . ' not exist ';
	// }
	function get($key){
		return $this->$key;
	}
	function __isset($key){
		if (property_exists('magic', $key)) {
			echo 'property ' . $key . ' exists<br/>';
		} else {
			echo  'property ' . $key . ' not exists<br/>';
		}
	}
	function __unset($key){
		if (property_exists('magic', $key)) {
			unset($this->$key);
			echo 'property' . $key . ' has been unseted<br/>';
		} else {
			echo  'property ' . $key . ' not exists<br/>';
		}
	
	}

	function __call($func,$param){
		echo "$func method not exists <br/>";
		var_dump($param);
	}

	function __toString(){
		return 'when you want to echo or print the object, __toString() will be called';
	}
}

 $obj = new magic();
 print $obj;
 // $obj->register('param1','param2','param3');
 // echo $obj->_weight = '55kg ';
 // $obj->_name = 'chenxiaolong';
// echo $obj->get('_name');

// unset($obj->_hobby);
// //isset($obj->_hobby);
// unset($obj->lover);
// unset($obj->father);
// unset($obj->__height);
//echo $obj->_hobby;
?>