<?php
$dsn = "mysql:host=localhost;dbname=db_test";
$db = new PDO($dsn,'root','8731787');  // 创建数据库连接

// $author = ['陈小龙','陈大龙','李小龙','李大龙','张小龙','张大龙'];
// for ($i=0; $i < 100; $i++) { 
//   $sql = "insert into test_table (title,author,content,submit_time,click) values ('title" . $i . "','" . $author[rand(0,5)] . "','content" . $i . "','" . date('Y-m-d H:i:s') . "'," . rand(100,1000) . ")";
//   //echo $sql;
//   if($db->exec($sql)) {   //执行语句
//     echo "success<br/>";
//   } else {
//     var_dump($db->errorInfo());   // 错误信息
//     exit();
//   }
// }
 echo "<pre>";
 $sql = "select content from test_table where click>950";
 $res = $db->prepare($sql);  // 预处理sql语句
 $res->execute();
 while ($arr=$res->fetch(PDO::FETCH_OBJ)) {
   var_dump($arr);
 }



?>