<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/Library/WebServer/Documents/book/tp/public/../application/demo/view/index/test.html";i:1481995353;}*/ ?>
<html>
<head></head>

<body>
111

</body>
</html>