<?php
namespace app\demo\controller;
use think\Controller;

class Index extends Controller
{
	public function _initialize()
    {
        echo 'init<br/>';
    }
    public function test($data)
    {
    	echo 'test'.$data;

    	return 'hello,world!';
    	return view();
    }
}
