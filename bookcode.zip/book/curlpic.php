<?php
$token = 'pGh2ERrX391CM4z1IBcoJM2NDTWkM04WbOxVM_oUr-2a6iJbHFsmLYdYbyoLzYuo--I2hIsEjhGJ-6sExOBbwaHbmJ8rOAM4Iyc1YC9DcPXak7Ufjpu9dDLIKPMOxiaFNQRiAIASVW';
$url = "https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=$token&type=image";
$url = "https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=$token";

//$url = "https://api.weixin.qq.com/cgi-bin/material/add_news?access_token=$token";
$picpath = 'chen.jpg';

$data = '{
  "articles": [{
       "title": "TITLE",
       "thumb_media_id": "OSqGKw5I9hMgJ0P742gppBmaLa9OXjI1qgbXYrfRPb4_sSOip9rleZXpHbcVdrs6",
       "author": "AUTHOR",
       "digest": "DIGEST",
       "show_cover_pic": 1,
       "content": "CONTENT",
       "content_source_url": "http://www.baidu.com"
    },
   
 ]
}';


$res = curl_post($url,$picpath);
var_dump($res);
function curl_post($url,$data){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	if(!empty($data)) {


		if (class_exists('\CURLFile')) { 
		curl_setopt($ch, CURLOPT_POST, 1);
		$cfile = new CURLFile($data);
		$data = array('test_file' => $cfile);  
		
		} else {    
			$path = "/H58295667/wwwroot/taikr/chen.jpg";
			$data = array('fieldname' => '@' . $path);
		}
		
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	}
	// var_dump($data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);
	curl_close($ch);
	return $res;
}

?>