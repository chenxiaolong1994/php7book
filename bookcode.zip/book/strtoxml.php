<?php
header('Content-Type:text/xml');
$xmlstr = <<<XML
<?xml version='1.0' standalone='yes'?>
<movies>
 <movie>
  <title>PHP: Behind the Parser</title>
  <characters>
   <character>
    <name>Ms. Coder</name>
    <actor>Onlivia Actora</actor>
   </character>
   <character>
    <name>Mr. Coder</name>
    <actor>El Act&#211;r</actor>
   </character>
  </characters>
  <plot>
   So, this language. It's like, a programming language. Or is it a
   scripting language? All is revealed in this thrilling horror spoof
   of a documentary.
  </plot>
  <great-lines>
   <line>PHP solves all my web problems</line>
  </great-lines>
  <rating type="thumbs">7</rating>
  <rating type="stars">5</rating>
 </movie>
</movies>
XML;
//echo $xmlstr;

//echo "<books>\n";
// $books = array(array('bookname'=>'微信公众平台开发实战与应用案例',
// 					 'author'=>'陈小龙',
// 					 'press'=>'清华大学出版社',
// 					 'publishtime'=>'2016-07'),

// 			   array('bookname'=>'php快速开发入门 o2o网站和app后台开发',
// 			   		 'author'=>'陈小龙',
// 			   		 'press'=>'清华大学出版社',
// 			   		 'publishtime'=>'2017-07'));

// foreach ($books as $book) {
// 	echo "	<book>\n";
// 	foreach ($book as $tag => $value) {
// 		echo "		<$tag>" . htmlspecialchars($value) . "</$tag>\n";
// 	}
// 	echo "	</book>\n";
// }
// echo "</books>";

$dom = new DOMDocument('1.0','utf-8');
//创建一个根元素，并将其添加到文档
$book = $dom->appendChild($dom->createElement('book'));

//创建一个bookname元素，并将其添加到$book
$bookname = $book->appendChild($dom->createElement('bookname'));
//设置bookname元素中文本
$bookname->appendChild($dom->createTextNode('微信公众平台开发实战与应用案例'));

$author = $book->appendChild($dom->createElement('author'));
$author->appendChild($dom->createTextNode('陈小龙'));
//设置author中属性和值
$author->setAttribute('age','22 years old');

$press = $book->appendChild($dom->createElement('press'));
$press->appendChild($dom->createTextNode('清华大学出版社'));

$publishtime = $book->appendChild($dom->createElement('publishtime'));
$publishtime->appendChild($dom->createTextNode('2016-07'));

//格式化xml数据
$dom->formatOutput = true;
//echo $dom->saveXML();

?>