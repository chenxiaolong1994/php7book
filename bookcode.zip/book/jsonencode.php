<?php
// echo "连续数组";
// $sequential = array("foo", "bar", "baz", "blong");
// echo json_encode($sequential);
// echo "<br/>非连续数组";
// $nonsequential = array(1=>"foo", 2=>"bar", 3=>"baz", 4=>"blong");
// echo json_encode($nonsequential);
// echo "<br/>删除一个连续数组值的方式产生的非连续数组";
// unset($sequential[1]);
// echo json_encode($sequential);
// echo "<br/>二维数组";
// $arr = array(array('name'=>'chenxiaolong'),array('name'=>'zhangsan'));
// echo json_encode($arr);



$json = '{"a":1,"b":2,"c":3,"d":4,"e":5}';
var_dump(json_decode($json));
echo "<br/>";
var_dump(json_decode($json, true));
?>