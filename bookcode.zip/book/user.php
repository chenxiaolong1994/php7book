<?php
var_dump($_POST);
var_dump($_FILES);
if ($_FILES["video"]["error"] > 0)
  {
  echo "Error: " . $_FILES["video"]["error"] . "<br />";
  } else {
  	print_r($_FILES["video"]); 
if(is_uploaded_file($_FILES['video']['tmp_name'])){ 
$upfile=$_FILES["video"]; 
//获取数组里面的值 
$name=$upfile["name"];//上传文件的文件名 
$type=$upfile["type"];//上传文件的类型 
$size=$upfile["size"];//上传文件的大小 
$tmp_name=$upfile["tmp_name"];//上传文件的临时存放路径 
move_uploaded_file($tmp_name, '/Library/WebServer/Documents/book/'.$name);
}
  }
?>