<?php

$access_token = 'Vf4j8JoML0cv23hbDP4QuAUFgFp6-S077-EeJ8Ki5faZzNSiZkdPukyMJwsOtYDlvx1EPjKXCVnv2bdIpdm8NnfXt2W3xQOTWAGjzIL7wrJeO9AhSsgS7qsaCdCwUzODWBHjACAFKQ';

$url = 'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=' . $access_token;
$data = '{
           "touser":"o0Ufpty46XrLN4oE3VQ00G82K6xA",
           "template_id":"jSP9gkg-IbvBHq_b1DGPirR41GNsa0rzxKWTa6i93K8",
           "url":"http://baidu.com",            
           "data":{
                   "name": {
                       "value":"陈小龙",
                       "color":"#173177"
                   },
                   "age":{
                       "value":"22",
                       "color":"#173177"
                   },
                   "phone": {
                       "value":"1888888888",
                       "color":"#173177"
                   }
           }
       }';
var_dump(curl_post($url,$data));

function curl_post($url,$data){
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	if(!empty($data)) {
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	}
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($curl);
	curl_close($curl);
	return $res;
}

?>