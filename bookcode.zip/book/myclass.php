<?php
class myclass{
	function myname(){
		echo "My name is chenxiaolong ";
	}
}
?>