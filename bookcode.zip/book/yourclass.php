<?php
class yourclass{
	function yourname(){
		echo "Your name is lixiaolong ";
	}
}
?>