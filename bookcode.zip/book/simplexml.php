<?php

include 'xmlstr.php';


$sxe = new SimpleXMLElement($xmlstr);





$path = $sxe->xpath('/movies/movie/characters');

echo ($path[0]->character->name);
echo "<pre>";
var_dump($path);
$sxe->addAttribute('type', 'documentary');
$test = $sxe->movie[0]->addChild('test','chr');
$test->addAttribute('ta','taa');
echo (string)$test['ta'];
var_dump((string)$test);
var_dump($sxe->movie[0]->plot);

$movies = $sxe->movie[1]->title;
echo (string)$sxe['type'];
echo  (string)$movies['tt'];

//print_r($sxe);
$string = <<<XML
<a>
 <foo name="one" game="lonely">1</foo>
 <foo name="one1" game="lonely1">1</foo>
</a>
XML;
echo "<p>";
$xml = simplexml_load_string($string);
$xml2 = new SimpleXMLElement($string);
print_r($xml2);
var_dump($xml);
foreach($xml2->foo[1]->attributes() as $a => $b) {
    echo $a,'="',$b,"\"\n";
}


//echo $sxe->asXML();

?>