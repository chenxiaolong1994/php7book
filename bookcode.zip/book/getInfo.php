<?php
$token = "aJrwXTpzYVzroL0Fz8laPoHyTXZgbCG_XS2HUKDHnn8q35mAjOoMe2-tFAm1mokoykwz4xwoGPCJdO8DPktCR_yS4A2ldSxK8knO_N5QKaEYMGbAIAQEY";

$url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" . $token . "&openid=o0Ufpty46XrLN4oE3VQ00G82K6xA&lang=zh_CN";
var_dump(file_get_contents($url));

?>