<?php
//include 'xmlstr.php';
$xmlstr = <<<XML
<?xml version='1.0' standalone='yes'?>
<movies attr='qwe' hah='fasdf'>
 <movie a='aa'>
  <title tt='ttt'>PHP: Behind the Parser</title>
  <characters>
   <character>
    <name age='22 years old' country='china'>Ms. Coder</name>
    <actor>Onlivia Actora</actor>
   </character>
   <character>
    <name>Mr. Coder</name>
    <actor>El Act&#211;r</actor>
   </character>
  </characters>
  <plot>
   So, this language. It's like, a programming language. Or is it a
   scripting language? All is revealed in this thrilling horror spoof
   of a documentary.
  </plot>
  <great-lines>
   <line>PHP solves all my web problems</line>
  </great-lines>
  <rating type="thumbs">7</rating>
  <rating type="stars">5</rating>
 </movie>
</movies>
XML;

$dom = new DOMDocument;
$dom->loadXML($xmlstr);
//获取标签<character>，并循环获得子元素的节点内容
$movie = $dom->getElementsByTagname('character');
foreach ($movie as $key => $value) {
	$name = $value->getElementsByTagname('name');
	echo $name->item(0)->firstChild->nodeValue,"<br/>";
}
//获得属性值
$attr = $dom->getElementsByTagname('character')[0]->getElementsByTagname('name')->item(0)->attributes;
foreach ($attr as $key => $value) {
	echo $key,":", $value->value,'<br/>';
}
//使用getAttribute获得属性值
$age = $dom->getElementsByTagname('character')[0]->getElementsByTagname('name')->item(0)->getAttribute('age');
echo $age;
?>