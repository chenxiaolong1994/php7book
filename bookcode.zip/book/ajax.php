<html>
<head>
<meta charset="utf-8">
<script src="http://cdn.static.runoob.com/libs/angular.js/1.4.6/angular.min.js"></script>
</head>
<body>

<div ng-app="myApp" ng-controller="siteCtrl">  
  <div ng-repeat="x in names">
  	姓名：<input id='name' value={{x.name}} style='color:red;'><br/>
	年龄：<input id='age' value={{x.age}} style='color:blue'><br/>
	公司：<input id='company' value={{x.company}} style='color:green'><br/> 
  </div>
</div>

<script>
var app = angular.module('myApp', []);
app.controller('siteCtrl', function($scope, $http) {
  $http.get("info.php").success(function (response) {$scope.names = response.data;});
});
</script>

</body>
</html>