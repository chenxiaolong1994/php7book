<?php

//定义接口
interface Calc{
  public function getValue($num1,$num2);
}

//四个类表示四种可供选择的策略
class AddStrategy implements Calc {
  public function getValue($m,$n){
    echo $m + $n;
  }
}

class SubStrategy implements Calc {
  public function getValue($m,$n){
    echo $m - $n;
  }
}

class MulStratygy implements Calc {
  public function getValue($m,$n){
    echo $m * $n;
  }
}

class DivStrategy implements Calc {
  public function getValue($m,$n){
    try {
      if($n == 0) {
        throw new Exception("除数不能为0");
      } else {
        echo $m/$n;
      }
      } catch (Exception $e) {
        echo "错误信息：" . $e->getMessage();
    }
  }
}

class CalcContext{
  private $_strategy = null;
  public function __construct(Calc $select){
    $this->_strategy = $select;
  }
  //设置使用的策略类
  public function setCalc(Calc $select){
    return $this->_strategy = $select;
  }
  public function calcResult($m,$n){
    $this->_strategy->getValue($m,$n);
  }
}

$result = new CalcContext(new AddStrategy());
$result->calcResult(10,2);
$result->setCalc(new DivStrategy());
$result->calcResult(10,2);


?>