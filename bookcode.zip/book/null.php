<?php

var_dump(getdate(time()+86400*30*10));

?>