<?php
class Connection 
{
    protected $link;
    public $server, $username, $password, $db;
    
      private function connect()
    {
        $this->link = mysql_connect($this->server, $this->username, $this->password);
        mysql_select_db($this->db, $this->link);
    }
    
    public function __sleep()
    {
        return array('server', 'password', 'db');
    }
    
    public function __wakeup()
    {
        echo 11;
            }
}
$obj = new Connection();
$obj->server = 'sss';
echo serialize($obj);

?>