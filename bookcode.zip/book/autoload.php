<?php

class father{
	public $name = 'chenxiaolong';
	function test(){
		echo "test";
	}
}
$obj = new father();
$obj_2 = clone $obj;
$obj_3 = $obj;
var_dump(($obj==$obj_2),($obj===$obj_2),($obj===$obj_3));


?>