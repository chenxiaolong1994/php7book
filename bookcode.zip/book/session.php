<?php
session_start();
$_SESSION['a'] = 'aa';
$str = "4680c9df2ce9ac4d1aa7f366bd92d83a";
echo strlen($str);
?>