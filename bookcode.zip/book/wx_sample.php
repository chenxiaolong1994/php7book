<?php
/**
  * wechat php test
  */

//define your token
define("TOKEN", "weixin");
$wechatObj = new wechatCallbackapiTest();
// $wechatObj->valid();
$wechatObj->index();

class wechatCallbackapiTest
{

    public function index(){
        if(isset($_GET['echostr'])) {
            $this->valid();
        } else {
            $this->responseMsg();
        }
    }

    public function valid()
    {
        $echoStr = $_GET["echostr"];

        //valid signature , option
        if($this->checkSignature()){
            echo $echoStr;
            exit;
        }
    }

    public function responseMsg()
    {
        //get post data, May be due to the different environments
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

        //extract post data
        if (!empty($postStr)){
                /* libxml_disable_entity_loader is to prevent XML eXternal Entity Injection,
                   the best way is to check the validity of xml by yourself */
                libxml_disable_entity_loader(true);
                $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
                $fromUsername = $postObj->FromUserName;
                $toUsername = $postObj->ToUserName;
                $keyword = trim($postObj->Content);
                $type = $postObj->MsgType;
                $time = time();
                $textTpl = "<xml>
                            <ToUserName><![CDATA[%s]]></ToUserName>
                            <FromUserName><![CDATA[%s]]></FromUserName>
                            <CreateTime>%s</CreateTime>
                            <MsgType><![CDATA[%s]]></MsgType>
                            <Content><![CDATA[%s]]></Content>
                            <FuncFlag>0</FuncFlag>
                            </xml>";  

                $imgTpl = "<xml>
                            <ToUserName><![CDATA[%s]]></ToUserName>
                            <FromUserName><![CDATA[%s]]></FromUserName>
                            <CreateTime>%s</CreateTime>
                            <MsgType><![CDATA[%s]]></MsgType>
                            <Image>
                            <MediaId><![CDATA[%s]]></MediaId>
                            </Image>
                            </xml>"; 

                $voiceTpl = "<xml>
                                <ToUserName><![CDATA[%s]]></ToUserName>
                                <FromUserName><![CDATA[%s]]></FromUserName>
                                <CreateTime>%s</CreateTime>
                                <MsgType><![CDATA[%s]]></MsgType>
                                <Voice>
                                <MediaId><![CDATA[%s]]></MediaId>
                                </Voice>
                                </xml>";
                $videoTpl = "<xml>
                            <ToUserName><![CDATA[%s]]></ToUserName>
                            <FromUserName><![CDATA[%s]]></FromUserName>
                            <CreateTime>%s</CreateTime>
                            <MsgType><![CDATA[%s]]></MsgType>
                            <Video>
                            <MediaId><![CDATA[%s]]></MediaId>
                            <Title><![CDATA[%s]]></Title>
                            <Description><![CDATA[%s]]></Description>
                            </Video> 
                            </xml>
                            ";
            $musicTpl = "<xml>
                        <ToUserName><![CDATA[%s]]></ToUserName>
                        <FromUserName><![CDATA[%s]]></FromUserName>
                        <CreateTime>%s</CreateTime>
                        <MsgType><![CDATA[%s]]></MsgType>
                        <Music>
                        <Title><![CDATA[%s]]></Title>
                        <Description><![CDATA[%s]]></Description>
                        <MusicUrl><![CDATA[%s]]></MusicUrl>
                        <HQMusicUrl><![CDATA[%s]]></HQMusicUrl>
                        <ThumbMediaId><![CDATA[%s]]></ThumbMediaId>
                        </Music>
                        </xml>
                        ";

                $newsTpl = "<xml>
                        <ToUserName><![CDATA[%s]]></ToUserName>
                        <FromUserName><![CDATA[%s]]></FromUserName>
                        <CreateTime>%s</CreateTime>
                        <MsgType><![CDATA[%s]]></MsgType>
                        <ArticleCount>2</ArticleCount>
                        <Articles>
                        <item>
                        <Title><![CDATA[%s]]></Title> 
                        <Description><![CDATA[%s]]></Description>
                        <PicUrl><![CDATA[%s]]></PicUrl>
                        <Url><![CDATA[%s]]></Url>
                        </item>
                        <item>
                        <Title><![CDATA[%s]]></Title>
                        <Description><![CDATA[%s]]></Description>
                        <PicUrl><![CDATA[%s]]></PicUrl>
                        <Url><![CDATA[%s]]></Url>
                        </item>
                        </Articles>
                        </xml>";

                if($type == 'text') {
                        $picurl = 'http://i3.mifile.cn/a4/T1UQAgB7_v1RXrhCrK.jpg';

                       $echo  = sprintf($newsTpl,$fromUsername,$toUsername,$time,'news','title1','description1',$picurl,'http://baidu.com','title2','description2',$picurl,'http://taikr.com');



                    // if ($keyword == 1) ｛
                        // $musicUrl = 'http://sc.111ttt.com/up/mp3/161940/AAA1CD69EBEED018C3AC9CE6CCB8C3B3.mp3';
                        // $media_id = '7Wn1YzkjjNMJ-ZFIUbbQjItbMi6zVzlKoCdvRpkZYSg8yew5yV8yCe8QRx4X4NAR';
                        //     $echo = sprintf($musicTpl,$fromUsername,$toUsername,$time,'music','音乐标题','音乐描述',$musicUrl,$musicUrl,$media_id);
                        // } else {
                        //     $str = '你发送的是文本消息' . $keyword;
                        //      $MsgType = 'text';
                        //      $echo  = sprintf($textTpl,$fromUsername,$toUsername,$time,$MsgType,$str);
                        // }


                  
                } else if ($type == 'image'){
                    $MsgType = 'image';

                    $media_id = '7Wn1YzkjjNMJ-ZFIUbbQjItbMi6zVzlKoCdvRpkZYSg8yew5yV8yCe8QRx4X4NAR';
                    $media_id = $postObj->MediaId;
                    $echo = sprintf($imgTpl,$fromUsername,$toUsername,$time,$MsgType,$media_id);
                    
                } else if ($type == 'voice') {
                
                    $str = $postObj->Recognition;
                     $str = '你说话的语音识别结果是' . $postObj->Recognition;
                    $MsgType = 'text';
                     $echo  = sprintf($textTpl,$fromUsername,$toUsername,$time,$MsgType,$str);

                } else if ($type == 'video') {
                    $str = '你发送的是视频消息,Id是' . $postObj->MediaId;
                    $MsgType = 'text';
                     $echo  = sprintf($textTpl,$fromUsername,$toUsername,$time,$MsgType,$str);
                   // $MsgType = 'video';
                   // $title = '视频标题';
                   // $desc = '视频描述';
                   // $echo = sprintf($videoTpl,$fromUsername,$toUsername,$time,$MsgType,$postObj->MediaId,$title,$desc);
                } else if ($type == 'location') {
                    $str = '你发送的是地理位置消息,纬度是' . $postObj->Location_X. " 经度是" . $postObj->Location_Y . "名称" . $postObj->Label . "精度是" . $postObj->Scale;
                    $MsgType = 'text';
                     $echo  = sprintf($textTpl,$fromUsername,$toUsername,$time,$MsgType,$str);
                } else if ($type == 'link') {
                     $str = '你发送的是链接消息'  . $postObj->title  . $postObj->Description . $postObj->Url;
                    $MsgType = 'text';
                     $echo  = sprintf($textTpl,$fromUsername,$toUsername,$time,$MsgType,$str);
                } else if ($type == 'event') {
                    if ($postObj->EventKey == 'V1001_TODAY_MUSIC') {
                          $musicUrl = 'http://sc.111ttt.com/up/mp3/161940/AAA1CD69EBEED018C3AC9CE6CCB8C3B3.mp3';
                         $media_id = '7Wn1YzkjjNMJ-ZFIUbbQjItbMi6zVzlKoCdvRpkZYSg8yew5yV8yCe8QRx4X4NAR';
                         $echo = sprintf($musicTpl,$fromUsername,$toUsername,$time,'music','音乐标题','音乐描述',$musicUrl,$musicUrl,$media_id);
                    } else if ($postObj->EventKey == 'V1001_GOOD') {
                        $str = 'thank you for your zan';
                       $MsgType = 'text';
                       $echo  = sprintf($textTpl,$fromUsername,$toUsername,$time,$MsgType,$str);
                    }
                }


               
                echo $echo;

        }else {
            echo "";
            exit;
        }
    }
        
    private function checkSignature()
    {
        // you must define TOKEN by yourself
        if (!defined("TOKEN")) {
            throw new Exception('TOKEN is not defined!');
        }
        
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
                
        $token = TOKEN;
        $tmpArr = array($token, $timestamp, $nonce);
        // use SORT_STRING rule
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );
        
        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }
}

?>