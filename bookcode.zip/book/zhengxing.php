<?php

$x = 5985;             // 定义一个整型数据类型的变量
var_dump($x);      // 输出此变量
echo "<br>"; 
$x = -345; 
var_dump($x);     
echo "<br>"; 
$x = 0x8C;   //十六进制数字
var_dump($x);   
echo "<br>";
$x = 047;  //八进制数字
var_dump($x);

?>