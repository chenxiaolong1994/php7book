<?php
$data = array(array('name'=>'chenxiaolong','age'=>'22','company'=>'360 company'),
			  array('name'=>'chendalong','age'=>'44','company'=>'ali company'),
		      array('name'=>'chenlaolong','age'=>'88','company'=>'baidu company'),
				);
$success = array('status'=>0,'msg'=>'success','data'=>$data);
echo json_encode($success);
?>